package com.example.batterytest.adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.batterytest.fragments.battery_fragment;
import com.example.batterytest.fragments.log_fragment;

public class fragmentsadapter extends FragmentStatePagerAdapter {

    public fragmentsadapter(@NonNull FragmentManager fm) {
        super(fm);
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){

            case 0: return new battery_fragment();

            case 1: return new log_fragment();

            default: return new battery_fragment();

        }
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if (position == 0){
            title = "Battery";
        }
        if (position == 1){
            title = "Log";
        }
        return title;
    }
}
