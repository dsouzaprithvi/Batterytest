package com.example.batterytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import com.example.batterytest.adapters.fragmentsadapter;
import com.example.batterytest.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.ntt.customgaugeview.library.GaugeView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    ActivityMainBinding binding;
    String status;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        status = getIntent().getStringExtra("STATUS");
        auth = FirebaseAuth.getInstance();



        binding.viewPager.setAdapter(new fragmentsadapter(getSupportFragmentManager()));
        binding.tablayout.setupWithViewPager(binding.viewPager);
        binding.tablayout.getTabAt(0).setIcon(R.drawable.ic_batter_icon);
        binding.tablayout.getTabAt(1).setIcon(R.drawable.ic_log_file_format);
//        final GaugeView gaugeView = (GaugeView) findViewById(R.id.gauge_view);
//        final Button btnStart = (Button) findViewById(R.id.btn_start);
//        gaugeView.setShowRangeValues(true);
//        gaugeView.setTargetValue((float) 24);
//        final Random random = new Random();
//        final CountDownTimer timer = new CountDownTimer(10000, 2) {
//            @Override
//            public void onTick(long millisUntilFinished) {
//                gaugeView.setTargetValue(random.nextInt(24));
//            }
//
//            @Override
//            public void onFinish() {
//                gaugeView.setTargetValue(0);
//            }
//        };
//        btnStart.setOnClickListener(v -> timer.start());
//    }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.edit_device) {

            Intent intent = new Intent(MainActivity.this, Editdevice.class);
            startActivity(intent);
            return true;
        }


        if (id == R.id.logout) {

            auth.signOut();
            Intent intent = new Intent(MainActivity.this, Splashscreen.class);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public Bundle getMyData() {
        Bundle bundle = new Bundle();
        bundle.putString("status", status);
        return bundle;
    }
}