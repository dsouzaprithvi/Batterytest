package com.example.batterytest.models;

public class loginfo {


    String date, time, voltage;

    public loginfo(String date, String time, String voltage) {
        this.date = date;
        this.time = time;
        this.voltage = voltage;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }
}
