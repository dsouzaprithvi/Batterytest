package com.example.batterytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class Splashscreen extends AppCompatActivity {

    //duration for splash screen
    public static int SPLASH_SCREEN = 4000;

    //Variables
    Animation topanim, bottomanim;
    ImageView logoimage;
    TextView text1, text2, text3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);


        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);


        //hooks
        logoimage = findViewById(R.id.logo);
        logoimage.setAnimation(topanim);
        text1 = findViewById(R.id.text1);
        text1.setAnimation(topanim);
        text2 = findViewById(R.id.text2);
        text2.setAnimation(topanim);
        text3 = findViewById(R.id.text3);
        text3.setAnimation(topanim);

        //after animation is completed going to next activity
        new Handler().postDelayed(() -> {

            Intent intent = new Intent(Splashscreen.this, Enterotpscreen.class);
            startActivity(intent);
            finish();

        },SPLASH_SCREEN);
    }
}