package com.example.batterytest.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import com.example.batterytest.Preconfig;
import com.example.batterytest.R;
import com.example.batterytest.adapters.logadapter;
import com.example.batterytest.models.loginfo;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class log_fragment extends Fragment {

    RecyclerView recyclerView;
    logadapter adapter;
    ArrayList<loginfo> logholder;

    Button refresh;

    public log_fragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_log_fragment, container, false);

        refresh = view.findViewById(R.id.refresh);

        logholder = Preconfig.readListFromPref(getContext());
        if(logholder == null){
            logholder = new ArrayList<>();
        }
        adapter = new logadapter(logholder, getContext());

        recyclerView = view.findViewById(R.id.logs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);


        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateview();
            }
        });


        return view;
    }

    private void updateview() {

        logholder = Preconfig.readListFromPref(getContext());
        adapter = new logadapter(logholder, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }

}