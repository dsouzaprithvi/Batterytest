package com.example.batterytest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Verifyotpscreen extends AppCompatActivity {

    Button verifyotp, resendotp;
    TextView timerview, resendotpagain;
    EditText inputnumber1, inputnumber2, inputnumber3, inputnumber4, inputnumber5, inputnumber6;
    String getotpbackend, recievedotp, mobilenumber;
    ProgressBar progressBar;
    Dialog dialog;
    RelativeLayout dialog_layout;
    FirebaseAuth mAuth;
    FirebaseDatabase database;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyotpscreen);

        verifyotp = findViewById(R.id.verify_otp);

        inputnumber1 = findViewById(R.id.inputotp1);
        inputnumber2 = findViewById(R.id.inputotp2);
        inputnumber3 = findViewById(R.id.inputotp3);
        inputnumber4 = findViewById(R.id.inputotp4);
        inputnumber5 = findViewById(R.id.inputotp5);
        inputnumber6 = findViewById(R.id.inputotp6);

        //Display mobile number in text field with code
        TextView textView = findViewById(R.id.textmobile);
        textView.setText(getIntent().getStringExtra("mobile"));
        mobilenumber = getIntent().getStringExtra("mobile").toString();

        timerview = findViewById(R.id.timer);
        resendotpagain = findViewById(R.id.textresendotp);
        resendotp = findViewById(R.id.resend_otp);
        progressBar = findViewById(R.id.progressbar_verify_otp);

        //inflate view to display verified dialog
        View view = getLayoutInflater().inflate(R.layout.verified_dialog, null);
        //hook after layout is inflated
        dialog_layout = view.findViewById(R.id.dialog_layout);
        //set dialog theme
        dialog = new Dialog(this, R.style.Theme_Batterytest);
        dialog.setContentView(view);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        initiateotp();

        timerfunction();

        verifyotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!inputnumber1.getText().toString().trim().isEmpty() && !inputnumber2.getText().toString().trim().isEmpty() &&
                        !inputnumber3.getText().toString().trim().isEmpty() && !inputnumber4.getText().toString().trim().isEmpty() &&
                        !inputnumber5.getText().toString().trim().isEmpty() && !inputnumber6.getText().toString().trim().isEmpty()){

                    String enterotp = inputnumber1.getText().toString() + inputnumber2.getText().toString() +
                            inputnumber3.getText().toString() + inputnumber4.getText().toString() +
                            inputnumber5.getText().toString() + inputnumber6.getText().toString();

                    if( getotpbackend != null){
                        progressBar.setVisibility(View.VISIBLE);
                        verifyotp.setVisibility(View.INVISIBLE);
                        Log.i("otp ", getotpbackend);



                        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(getotpbackend, enterotp);
                        signInWithPhoneAuthCredential(phoneAuthCredential);



                    }
                    else {
                        Toast.makeText(Verifyotpscreen.this, "Please check Internet connection", Toast.LENGTH_SHORT).show();
                    }


//                    Toast.makeText(verifyotptwo.this, "OTP verified", Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(Verifyotpscreen.this, "Please enter the otp", Toast.LENGTH_SHORT).show();
                }

            }
        });

        numberotpmove();//move cursor to next box when entering number and come back to previous box when deleted

        resendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resendotp.setVisibility(View.GONE);
                resendotpagain.setVisibility(View.VISIBLE);
                timerfunction();

                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        getIntent().getStringExtra("mobile"), 60, TimeUnit.SECONDS, Verifyotpscreen.this,
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {



                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {



                                Toast.makeText(Verifyotpscreen.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                            }

                            @Override
                            public void onCodeSent(@NonNull String newbackendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                getotpbackend = newbackendotp;
                                Toast.makeText(Verifyotpscreen.this, "OTP Sent again", Toast.LENGTH_SHORT).show();



                            }
                        });
            }
        });

    }

    private void timerfunction() {
        timerview.setVisibility(View.VISIBLE);
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                timerview.setText(sDuration);
            }

            @Override
            public void onFinish() {

                resendotpagain.setVisibility(View.GONE);
                resendotp.setVisibility(View.VISIBLE);
                timerview.setVisibility(View.GONE);

            }
        }.start();


    }

    private void initiateotp() {

        PhoneAuthProvider.getInstance().verifyPhoneNumber(mobilenumber, 60, TimeUnit.SECONDS, Verifyotpscreen.this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {


                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                        String otp = phoneAuthCredential.getSmsCode();
                        String otplist[] = otp.split("");
                        signInWithPhoneAuthCredential(phoneAuthCredential);
                        progressBar.setVisibility(View.GONE);
                        verifyotp.setVisibility(View.VISIBLE);
                        inputnumber1.setText(otplist[0]);
                        inputnumber2.setText(otplist[1]);
                        inputnumber3.setText(otplist[2]);
                        inputnumber4.setText(otplist[3]);
                        inputnumber5.setText(otplist[4]);
                        inputnumber6.setText(otplist[5]);



                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {


                        Toast.makeText(Verifyotpscreen.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {


                        getotpbackend = backendotp;

                    }
                });

    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        progressBar.setVisibility(View.GONE);
                        verifyotp.setVisibility(View.VISIBLE);
                        Log.i("uot sethhiiihihi", getotpbackend);


                        if (task.isSuccessful()) {


//                          store data in firebase
                            database.getReference().child("users").child(mobilenumber).child("userid").setValue(mobilenumber);

                            Toast.makeText(Verifyotpscreen.this, "OTP Verified", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Verifyotpscreen.this, Adddevice.class);
                            intent.putExtra("mobile", mobilenumber);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);


                        } else {

                            Toast.makeText(Verifyotpscreen.this, "Enter the correct otp", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }

    private void numberotpmove(){

        inputnumber1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber2.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

        inputnumber2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber3.requestFocus();
                }
                else {
                    inputnumber1.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

        inputnumber3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber4.requestFocus();
                }
                else {
                    inputnumber2.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

        inputnumber4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber5.requestFocus();
                }
                else {
                    inputnumber3.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber6.requestFocus();
                }
                else {
                    inputnumber4.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().isEmpty()){
                    inputnumber5.requestFocus();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });




    }
}