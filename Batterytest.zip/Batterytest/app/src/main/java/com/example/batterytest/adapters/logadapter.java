package com.example.batterytest.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.batterytest.R;
import com.example.batterytest.models.loginfo;


import java.util.ArrayList;

public class logadapter extends RecyclerView.Adapter<logadapter.logViewholder>{


    ArrayList<loginfo> logholder;
    Context context;

    public logadapter(ArrayList<loginfo> logholder, Context context) {
        this.logholder = logholder;
        this.context = context;
    }

    @NonNull
    @Override
    public logViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_log, parent, false);
        return  new logViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull logViewholder holder, int position) {

        loginfo data = logholder.get(position);

        holder.date.setText(logholder.get(position).getDate());
        holder.time.setText(logholder.get(position).getTime());
        holder.volatge.setText(logholder.get(position).getVoltage());


    }

    @Override
    public int getItemCount() {
        return logholder.size();
    }

    public class logViewholder extends RecyclerView.ViewHolder{


        TextView date, time, volatge;

        public logViewholder(@NonNull View itemView) {
            super(itemView);

            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            volatge = itemView.findViewById(R.id.voltage);



        }
    }
}
